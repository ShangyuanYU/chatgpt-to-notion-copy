/**
 * Content Script - 在 Notion 页面中运行
 * 拦截粘贴事件，自动转换格式
 */

// 加载转换器
const converter = new NotionConverter();

// 检查是否启用自动转换
chrome.storage.sync.get(['autoConvert'], (result) => {
  const autoConvert = result.autoConvert !== false; // 默认启用

  if (autoConvert) {
    setupPasteInterceptor();
  }
});

/**
 * 设置粘贴拦截器
 */
function setupPasteInterceptor() {
  document.addEventListener('paste', handlePaste, true);
  console.log('ChatGPT to Notion: 自动转换已启用');
}

/**
 * 处理粘贴事件
 */
function handlePaste(event) {
  // 获取剪贴板数据
  const clipboardData = event.clipboardData || window.clipboardData;
  if (!clipboardData) return;

  const pastedText = clipboardData.getData('text/plain');
  if (!pastedText || !pastedText.trim()) return;

  // 转换文本
  try {
    const converted = converter.convertToNotionMarkdown(pastedText);

    // 如果转换后的内容与原文不同，使用转换后的内容
    if (converted !== pastedText) {
      event.preventDefault();
      event.stopPropagation();

      // 使用 execCommand 插入文本（更兼容的方式）
      insertTextAtCursor(converted);

      // 显示提示
      showNotification('✅ 格式已自动转换');
    }
  } catch (error) {
    console.error('ChatGPT to Notion: 转换失败', error);
  }
}

/**
 * 在光标位置插入文本
 */
function insertTextAtCursor(text) {
  // 方法1: 使用 document.execCommand（较旧但兼容性好的方法）
  const success = document.execCommand('insertText', false, text);
  
  if (!success) {
    // 方法2: 使用 Selection API（现代方法）
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      
      // 创建文本节点
      const textNode = document.createTextNode(text);
      range.insertNode(textNode);
      
      // 移动光标到插入文本的末尾
      range.setStartAfter(textNode);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);
    }
  }
}

/**
 * 显示通知
 */
function showNotification(message) {
  // 创建通知元素
  const notification = document.createElement('div');
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #4CAF50;
    color: white;
    padding: 12px 24px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    animation: fadeIn 0.3s;
  `;

  // 添加动画
  const style = document.createElement('style');
  style.textContent = `
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(style);

  document.body.appendChild(notification);

  // 3秒后移除
  setTimeout(() => {
    notification.style.animation = 'fadeIn 0.3s reverse';
    setTimeout(() => notification.remove(), 300);
  }, 2000);
}

// 监听来自 popup 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'convertClipboard') {
    // 从剪贴板读取并转换
    navigator.clipboard.readText().then(text => {
      const converted = converter.convertToNotionMarkdown(text);
      navigator.clipboard.writeText(converted).then(() => {
        showNotification('✅ 已转换并复制到剪贴板');
        sendResponse({ success: true });
      }).catch(err => {
        console.error('写入剪贴板失败', err);
        sendResponse({ success: false, error: err.message });
      });
    }).catch(err => {
      console.error('读取剪贴板失败', err);
      sendResponse({ success: false, error: err.message });
    });

    return true; // 保持消息通道开放
  }
});

