/**
 * Background Service Worker
 * 处理扩展的后台逻辑
 */

// 安装时初始化
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // 首次安装时设置默认值
    chrome.storage.sync.set({ autoConvert: true }, () => {
      console.log('ChatGPT to Notion: 扩展已安装，默认启用自动转换');
    });
  }
});

// 监听消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'log') {
    console.log('[ChatGPT to Notion]', request.message);
  }
});

