/**
 * ChatGPT 到 Notion 格式转换器
 * 将 Python 逻辑转换为 JavaScript
 */

class NotionConverter {
  /**
   * 保护代码块和公式，避免在处理过程中被破坏
   */
  protectCodeBlocksAndFormulas(text) {
    const replacements = {};
    let counter = 0;

    // 保护代码块 ```language\n...\n```
    const codeBlockPattern = /```[\s]*(\w+)?[\s]*\n([\s\S]*?)\n[\s]*```/g;
    text = text.replace(codeBlockPattern, (match) => {
      const placeholder = `__CODE_BLOCK_${counter}__`;
      replacements[placeholder] = match;
      counter++;
      return placeholder;
    });

    // 保护行内代码 `code`
    const inlineCodePattern = /`([^`\n]+)`/g;
    text = text.replace(inlineCodePattern, (match) => {
      const placeholder = `__INLINE_CODE_${counter}__`;
      replacements[placeholder] = match;
      counter++;
      return placeholder;
    });

    // 保护块级数学公式 $$...$$（必须先处理，避免与行内公式冲突）
    const blockFormulaPattern = /\$\$([^$]+)\$\$/g;
    text = text.replace(blockFormulaPattern, (match) => {
      const placeholder = `__BLOCK_FORMULA_${counter}__`;
      replacements[placeholder] = match;
      counter++;
      return placeholder;
    });

    // 保护行内数学公式 $...$（但不能是 $$）
    // 由于已经处理了 $$...$$，现在匹配的 $...$ 不会是块级公式的一部分
    const inlineFormulaPattern = /\$([^$\n]+)\$/g;
    text = text.replace(inlineFormulaPattern, (match, formula) => {
      const placeholder = `__INLINE_FORMULA_${counter}__`;
      replacements[placeholder] = match;
      counter++;
      return placeholder;
    });

    return { text, replacements };
  }

  /**
   * 恢复被保护的代码块和公式
   */
  restoreCodeBlocksAndFormulas(text, replacements) {
    let restored = text;
    for (const [placeholder, original] of Object.entries(replacements)) {
      restored = restored.replace(placeholder, original);
    }
    return restored;
  }

  /**
   * 修复代码块的格式问题
   */
  fixCodeBlocks(text) {
    // 标准化代码块开始标记：```lang 或 ``` lang -> ```lang
    text = text.replace(/```\s*(\w+)/g, '```$1');

    // 确保代码块有正确的换行
    text = text.replace(/```(\w+)([^\n])/g, '```$1\n$2');

    // 修复不完整的代码块（只有开始没有结束）
    const lines = text.split('\n');
    const fixedLines = [];
    let inCodeBlock = false;
    let codeBlockLang = null;

    for (const line of lines) {
      // 检测代码块开始
      const codeStartMatch = line.trim().match(/^```(\w+)?$/);
      if (codeStartMatch) {
        inCodeBlock = true;
        codeBlockLang = codeStartMatch[1] || '';
        fixedLines.push(`\`\`\`${codeBlockLang}`);
        continue;
      }

      // 检测代码块结束
      if (inCodeBlock && line.trim() === '```') {
        inCodeBlock = false;
        codeBlockLang = null;
        fixedLines.push('```');
        continue;
      }

      // 如果在代码块中，直接添加
      if (inCodeBlock) {
        fixedLines.push(line);
        continue;
      }

      // 不在代码块中
      fixedLines.push(line);
    }

    // 如果最后还在代码块中，添加结束标记
    if (inCodeBlock) {
      fixedLines.push('```');
    }

    return fixedLines.join('\n');
  }

  /**
   * 修复数学公式的格式问题
   */
  fixFormulas(text) {
    // 确保块级公式格式正确 $$...$$
    text = text.replace(/\$\$\s*([^$]+?)\s*\$\$/gs, '$$$1$$');

    // 确保行内公式格式正确 $...$
    // 注意：必须在处理块级公式之后处理，避免匹配 $$...$$ 中的 $
    text = text.replace(/\$\s*([^$\n]+?)\s*\$/g, '$$1$');

    return text;
  }

  /**
   * 清理文本中的其他格式问题
   */
  cleanText(text) {
    // 标准化换行符
    text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    // 移除行尾空格
    const lines = text.split('\n');
    const trimmedLines = lines.map(line => line.trimEnd());
    text = trimmedLines.join('\n');

    // 修复过多的连续空行（最多保留2个）
    text = text.replace(/\n{3,}/g, '\n\n');

    // 移除文档开头和结尾的空白
    text = text.trim();

    return text;
  }

  /**
   * 将 ChatGPT 内容转换为 Notion 友好的 Markdown 格式
   */
  convertToNotionMarkdown(text) {
    // 1. 首先标准化换行符
    text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    // 2. 修复代码块格式（在保护之前修复）
    text = this.fixCodeBlocks(text);

    // 3. 修复公式格式（在保护之前修复）
    text = this.fixFormulas(text);

    // 4. 保护代码块和公式（避免在清理过程中被破坏）
    const { text: protectedText, replacements } = this.protectCodeBlocksAndFormulas(text);

    // 5. 清理文本（不影响已保护的代码块和公式）
    let cleanedText = this.cleanText(protectedText);

    // 6. 恢复代码块和公式
    let finalText = this.restoreCodeBlocksAndFormulas(cleanedText, replacements);

    // 7. 最终清理（确保格式整洁）
    finalText = this.cleanText(finalText);

    return finalText;
  }
}

// 导出供其他脚本使用
if (typeof module !== 'undefined' && module.exports) {
  module.exports = NotionConverter;
}

