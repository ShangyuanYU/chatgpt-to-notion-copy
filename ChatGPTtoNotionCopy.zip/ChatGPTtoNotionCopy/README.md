# ChatGPT to Notion 格式转换器

一个浏览器扩展，自动将从 ChatGPT 复制的内容转换为 Notion 友好的格式，特别优化代码块和数学公式的显示。

## 功能特性

- ✅ 自动处理代码块格式（支持多种编程语言）
- ✅ 优化数学公式显示（支持行内公式 `$...$` 和块级公式 `$$...$$`）
- ✅ 自动修复常见的格式问题
- ✅ 支持自动转换模式（在 Notion 中粘贴时自动转换）
- ✅ 手动转换模式（点击按钮转换剪贴板内容）
- ✅ 美观的用户界面

## 安装方法

### Chrome / Edge / Brave

1. 下载或克隆此仓库
2. 打开 Chrome/Edge，进入扩展管理页面：
   - Chrome: `chrome://extensions/`
   - Edge: `edge://extensions/`
3. 启用"开发者模式"（右上角开关）
4. 点击"加载已解压的扩展程序"
5. 选择 `notion-plugin` 文件夹
6. 安装完成！

### Firefox

1. 下载或克隆此仓库
2. 打开 Firefox，进入 `about:debugging#/runtime/this-firefox`
3. 点击"临时载入附加组件"
4. 选择 `notion-plugin/manifest.json` 文件
5. 安装完成！

## 使用方法

### 方法一：自动转换（推荐）

1. 确保扩展已安装并启用
2. 打开扩展 popup（点击浏览器工具栏中的扩展图标）
3. 确保"自动转换"开关已开启
4. 从 ChatGPT 复制内容（Cmd/Ctrl + C）
5. 在 Notion 中直接粘贴（Cmd/Ctrl + V）
6. 内容会自动转换格式！

### 方法二：手动转换

1. 从 ChatGPT 复制内容
2. 点击浏览器工具栏中的扩展图标
3. 点击"转换剪贴板内容"按钮
4. 在 Notion 中粘贴（Cmd/Ctrl + V）

## 图标文件

扩展需要图标文件才能正常显示。你需要创建以下图标文件（或使用占位符）：

- `icon16.png` (16x16 像素)
- `icon48.png` (48x48 像素)
- `icon128.png` (128x128 像素)

你可以使用在线工具（如 [Favicon Generator](https://www.favicon-generator.org/)）或设计工具创建图标。

或者，你可以暂时使用以下方法创建占位符图标：

```bash
# 使用 ImageMagick（如果已安装）
convert -size 16x16 xc:#667eea icon16.png
convert -size 48x48 xc:#667eea icon48.png
convert -size 128x128 xc:#667eea icon128.png
```

## 支持的格式

### 代码块

```python
def hello():
    print("Hello, World!")
```

### 行内代码

使用 `code` 格式

### 数学公式

- 行内公式：$E = mc^2$
- 块级公式：

$$
\sum_{i=1}^{n} x_i = \frac{n(n+1)}{2}
$$

## 技术栈

- Manifest V3
- 原生 JavaScript（无需依赖）
- Chrome Extensions API

## 文件结构

```
notion-plugin/
├── manifest.json       # 扩展配置文件
├── converter.js        # 格式转换核心逻辑
├── content.js          # Notion 页面注入脚本
├── popup.html          # 弹出窗口 HTML
├── popup.js            # 弹出窗口脚本
├── background.js       # 后台服务脚本
├── icon16.png          # 16x16 图标
├── icon48.png          # 48x48 图标
├── icon128.png         # 128x128 图标
└── README.md           # 说明文档
```

## 开发说明

### 修改代码后重新加载

1. 进入扩展管理页面
2. 找到本扩展
3. 点击刷新图标 🔄

### 调试

- **Popup**: 右键点击扩展图标 → "检查弹出内容"
- **Content Script**: 在 Notion 页面按 F12，查看控制台
- **Background**: 在扩展管理页面点击"检查视图 service worker"

## 常见问题

### Q: 自动转换不工作？

A: 
1. 检查扩展是否已启用
2. 检查 popup 中的"自动转换"开关是否开启
3. 刷新 Notion 页面
4. 检查浏览器控制台是否有错误

### Q: 权限错误？

A: 确保扩展已获得以下权限：
- 剪贴板读取/写入权限
- Notion 网站访问权限

### Q: 公式显示不正常？

A: Notion 支持 LaTeX 数学公式，确保：
- 行内公式使用 `$...$`
- 块级公式使用 `$$...$$`

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！

