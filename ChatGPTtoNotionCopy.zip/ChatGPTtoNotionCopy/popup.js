/**
 * Popup Script
 */

const converter = new NotionConverter();

// DOM 元素
const convertBtn = document.getElementById('convertBtn');
const testBtn = document.getElementById('testBtn');
const statusDiv = document.getElementById('status');
const autoConvertToggle = document.getElementById('autoConvertToggle');

// 加载设置
chrome.storage.sync.get(['autoConvert'], (result) => {
  const autoConvert = result.autoConvert !== false; // 默认启用
  autoConvertToggle.checked = autoConvert;
});

// 转换按钮点击事件
convertBtn.addEventListener('click', async () => {
  try {
    // 读取剪贴板
    const text = await navigator.clipboard.readText();
    
    if (!text || !text.trim()) {
      showStatus('❌ 剪贴板为空，请先复制内容', 'error');
      return;
    }

    // 转换
    const converted = converter.convertToNotionMarkdown(text);
    
    // 写回剪贴板
    await navigator.clipboard.writeText(converted);
    
    showStatus(`✅ 转换完成！已复制到剪贴板 (${text.length} → ${converted.length} 字符)`, 'success');
    
    // 通知 content script（如果在 Notion 页面）
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url && tabs[0].url.includes('notion.so')) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'convertClipboard' });
      }
    });
  } catch (error) {
    console.error('转换失败:', error);
    showStatus(`❌ 转换失败: ${error.message}`, 'error');
  }
});

// 测试按钮点击事件
testBtn.addEventListener('click', async () => {
  const testText = `这是一个测试示例。

\`\`\`python
def hello():
    print("Hello, World!")
\`\`\`

行内代码示例：\`code\`

数学公式：
- 行内公式：$E = mc^2$
- 块级公式：

$$
\\sum_{i=1}^{n} x_i = \\frac{n(n+1)}{2}
$$

**粗体文本** 和 *斜体文本*`;

  try {
    const converted = converter.convertToNotionMarkdown(testText);
    await navigator.clipboard.writeText(converted);
    showStatus('✅ 测试示例已复制到剪贴板', 'success');
  } catch (error) {
    showStatus(`❌ 测试失败: ${error.message}`, 'error');
  }
});

// 自动转换开关
autoConvertToggle.addEventListener('change', (e) => {
  const enabled = e.target.checked;
  chrome.storage.sync.set({ autoConvert: enabled }, () => {
    showStatus(enabled ? '✅ 自动转换已启用' : '⏸️ 自动转换已禁用', 'success');
    
    // 通知 content script 更新
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url && tabs[0].url.includes('notion.so')) {
        chrome.tabs.reload(tabs[0].id);
      }
    });
  });
});

/**
 * 显示状态消息
 */
function showStatus(message, type) {
  statusDiv.textContent = message;
  statusDiv.className = `status ${type}`;
  
  // 3秒后清除成功消息
  if (type === 'success') {
    setTimeout(() => {
      statusDiv.className = 'status';
      statusDiv.textContent = '';
    }, 3000);
  }
}

